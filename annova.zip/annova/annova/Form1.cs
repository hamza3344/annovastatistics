﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace annova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<double> alldata = new List<double>();
            List<double> datasetmeans = new List<double>();
            List<List<double>> datasets = new List<List<double>>();
            foreach(string samples in textBox1.Text.Split("?"))
            {
                List<double> temp = new List<double>();
                foreach(string sample in samples.Split(","))
                {
                    temp.Add(double.Parse(sample));
                    alldata.Add(double.Parse(sample));
                }
                datasets.Add(temp);
            }
            double sumofsquarewithingroup = 0;
            double mean = 0;
            for(int i=0;i<=datasets.Count()-1;i++)
            {
                mean = datasets[i].Average();
                datasetmeans.Add(mean);
                sumofsquarewithingroup = sumofsquarewithingroup +
                    datasets[i].Sum(d => Math.Pow(d - mean, 2));
            }
            mean = alldata.Average();
            double sumofsquarewithdifferentgroups = datasetmeans.Sum(d => Math.Pow(d - mean, 2))*
                datasets[0].Count();
            double upper = sumofsquarewithdifferentgroups / (datasets.Count() - 1);
            double lower = sumofsquarewithingroup / ((datasets[0].Count() * datasets.Count()) - datasets.Count());
            double result = upper / lower;
            MessageBox.Show("F(" + (datasets.Count() - 1) + "," + ((datasets[0].Count() * datasets.Count()) - datasets.Count()) +
                ")=" + result);
        }
    }
}
